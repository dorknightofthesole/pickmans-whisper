Scriptname PickmansWhisperMainQuestScript extends Quest

; Pickman's Whisper — Slice A: gallery/blade bond, toast voice, knife hunger meter.
; Soft companion to Necromantic (no AAF, no compile coupling). Soft deps: F4SE, MCM; GoE2 optional for line files.

Actor PlayerRef
Form PickmansBlade
Cell PickmanGalleryCell

; --- Bond (Auto = saved with the quest) ----------------------------------------
Bool Property BondStarted = False Auto
Float Property BondStartGameTime = 0.0 Auto
Bool Property IntroToastShown = False Auto
Bool Property SeenGallery = False Auto
Bool Property SeenBlade = False Auto
; True once we've seen a unique Pickman's Blade instance (name match). Template FormID
; 0x22595F is CustomItem_DoNotPlaceDirectly_* — inventory copies often have other FormIDs.
Bool Property OwnedPickmansBlade = False Auto
Float Property BondIntensity = 0.0 Auto ; bumped in Slice B on knife kills
Float Property LastKnifeActivityGameTime = 0.0 Auto ; Slice B updates; A sets at bond start
String BLADE_NAME_NEEDLE = "Pickman's Blade"

; --- Hunger / addiction stand-in ----------------------------------------------
Float Property HungerLevel = 0.0 Auto ; 0–100 once bonded
Float Property SatedUntilGameTime = 0.0 Auto ; Slice B sets; A stubs only
Float LastHungerPollGameTime = 0.0
Int LastHungerBand = 0 ; 0/25/50/70/90
Bool HungerWasSated
Bool Property HungerAddictionApplied = False Auto
Bool Property HungerStatPenaltyApplied = False Auto
Spell KnifeHungerSpell
MagicEffect KnifeHungerAgiEffect
MagicEffect KnifeHungerChaEffect
GlobalVariable KnifeHungerGlobal
Bool HungerSpellLoadWarned
Float HUNGER_POLL_SECONDS = 12.0
Float BOND_POLL_SECONDS = 4.0
Float TRUST_VOICE_SECONDS = 180.0

Int TIMER_HUNGER = 1
Int TIMER_BOND = 2
Int TIMER_TRUST = 3

; Vanilla anchors (Fallout4.esm)
Int FID_PICKMANS_BLADE = 0x0022595F
Int FID_PICKMAN_GALLERY = 0x000379C5

; Local forms (PickmansWhisper.esp) — low word for GetFormFromFile
Int FID_HUNGER_SPEL = 0x00000801
Int FID_HUNGER_GLOB = 0x00000802
Int FID_HUNGER_MGEF_AGI = 0x00000803
Int FID_HUNGER_MGEF_CHA = 0x00000804

String MOD_NAME = "PickmansWhisper"
Int LINE_FILE_MAX = 64

String[] TrustLines
Int TrustLineCount = 0
String[] HungerLines
Int HungerLineCount = 0
Float LastTrustToastRealTime = 0.0
Float LastHungerToastRealTime = 0.0
Float TRUST_TOAST_COOLDOWN = 8.0
Float HUNGER_TOAST_COOLDOWN = 6.0

Event OnQuestInit()
	PlayerRef = Game.GetPlayer()
	ResolveVanillaForms()
	EnsureHungerSpell()
	RegisterForRemoteEvent(PlayerRef, "OnPlayerLoadGame")
	RegisterForRemoteEvent(PlayerRef, "OnItemEquipped")
	RegisterForRemoteEvent(PlayerRef, "OnItemAdded")
	RegisterForRemoteEvent(PlayerRef, "OnItemRemoved")
	RegisterForExternalEvent("OnMCMMenuOpen|PickmansWhisper", "OnMCMMenuOpen")
	RegisterForExternalEvent("OnMCMSettingChange|PickmansWhisper", "OnMCMSettingChange")
	LoadLineBanks()
	RefreshBladeOwnershipFromEquip()
	StartBondPoll()
	StartHungerPoll()
	StartTrustVoice()
	RefreshDebugStatus()
	RefreshHungerPanel(False)
	Debug.Trace("PickmansWhisper: quest init")
	Debug.Notification("Pickman's Whisper ready")
EndEvent

Event Actor.OnPlayerLoadGame(Actor akSender)
	PlayerRef = Game.GetPlayer()
	ResolveVanillaForms()
	EnsureHungerSpell()
	RegisterForRemoteEvent(PlayerRef, "OnItemEquipped")
	RegisterForRemoteEvent(PlayerRef, "OnItemAdded")
	RegisterForRemoteEvent(PlayerRef, "OnItemRemoved")
	LoadLineBanks()
	RefreshBladeOwnershipFromEquip()
	StartBondPoll()
	StartHungerPoll()
	StartTrustVoice()
	SyncHungerAddictionSpell()
	RefreshDebugStatus()
	RefreshHungerPanel(False)
	Debug.Trace("PickmansWhisper: player load")
EndEvent

Event Actor.OnItemEquipped(Actor akSender, Form akBaseObject, ObjectReference akReference)
	If IsPickmansBladeForm(akBaseObject)
		MarkOwnedBlade("equipped")
	EndIf
EndEvent

Event Actor.OnItemAdded(Actor akSender, Form akBaseItem, Int aiItemCount, ObjectReference akItemReference, ObjectReference akSourceContainer)
	If IsPickmansBladeForm(akBaseItem)
		MarkOwnedBlade("added")
	EndIf
EndEvent

Event Actor.OnItemRemoved(Actor akSender, Form akBaseItem, Int aiItemCount, ObjectReference akItemReference, ObjectReference akDestContainer)
	If IsPickmansBladeForm(akBaseItem)
		; Unique instance left inventory — clear only if nothing blade-like remains equipped/templated.
		If !IsBladeEquipped() && !HasTemplateBlade()
			OwnedPickmansBlade = False
			Debug.Trace("PickmansWhisper: blade ownership cleared (removed)")
		EndIf
	EndIf
EndEvent

Event OnTimer(Int aiTimerID)
	If aiTimerID == TIMER_BOND
		RunBondPoll()
		StartBondPoll()
	ElseIf aiTimerID == TIMER_HUNGER
		RunHungerTick()
		StartHungerPoll()
	ElseIf aiTimerID == TIMER_TRUST
		MaybeSpeakTrustLine()
		StartTrustVoice()
	EndIf
EndEvent

Function ResolveVanillaForms()
	If !PickmansBlade
		PickmansBlade = Game.GetFormFromFile(FID_PICKMANS_BLADE, "Fallout4.esm")
		If PickmansBlade
			Debug.Trace("PickmansWhisper: blade form loaded")
		Else
			Debug.Trace("PickmansWhisper: ERROR Pickman's Blade form missing")
		EndIf
	EndIf
	If !PickmanGalleryCell
		PickmanGalleryCell = Game.GetFormFromFile(FID_PICKMAN_GALLERY, "Fallout4.esm") as Cell
		If PickmanGalleryCell
			Debug.Trace("PickmansWhisper: gallery cell loaded")
		Else
			Debug.Trace("PickmansWhisper: ERROR PickmanGallery01 missing")
		EndIf
	EndIf
EndFunction

; --- Bond / trigger ------------------------------------------------------------

Function StartBondPoll()
	CancelTimer(TIMER_BOND)
	StartTimer(BOND_POLL_SECONDS, TIMER_BOND)
EndFunction

Function RunBondPoll()
	If !PlayerRef
		PlayerRef = Game.GetPlayer()
	EndIf
	If !PlayerRef || Utility.IsInMenuMode()
		Return
	EndIf
	ResolveVanillaForms()

	Bool inGallery = IsPlayerInGallery()
	Bool hasBlade = PlayerHasBlade()
	Bool equipped = IsBladeEquipped()

	If inGallery && !SeenGallery
		SeenGallery = True
		Debug.Trace("PickmansWhisper: entered Pickman Gallery")
	EndIf
	If hasBlade && !SeenBlade
		SeenBlade = True
		Debug.Trace("PickmansWhisper: acquired Pickman's Blade")
	EndIf

	If !BondStarted && (inGallery || hasBlade || equipped)
		StartBond("trigger")
	EndIf
EndFunction

Bool Function IsPlayerInGallery()
	If !PlayerRef
		Return False
	EndIf
	Cell cur = PlayerRef.GetParentCell()
	If !cur
		Return False
	EndIf
	If PickmanGalleryCell && cur == PickmanGalleryCell
		Return True
	EndIf
	Int id = cur.GetFormID()
	Int low = id - (id / 0x01000000) * 0x01000000
	Return low == FID_PICKMAN_GALLERY
EndFunction

Bool Function IsPickmansBladeForm(Form f)
	If !f
		Return False
	EndIf
	If PickmansBlade && (f == PickmansBlade || f.GetFormID() == PickmansBlade.GetFormID())
		Return True
	EndIf
	String n = f.GetName()
	If n == ""
		Return False
	EndIf
	; Unique lofted instances keep the display name even when FormID != template.
	Return StringUtil.Find(n, BLADE_NAME_NEEDLE) >= 0
EndFunction

Bool Function HasTemplateBlade()
	If !PlayerRef || !PickmansBlade
		Return False
	EndIf
	Return PlayerRef.GetItemCount(PickmansBlade) > 0
EndFunction

Function MarkOwnedBlade(String reason)
	OwnedPickmansBlade = True
	If !SeenBlade
		SeenBlade = True
		Debug.Trace("PickmansWhisper: acquired Pickman's Blade (" + reason + ")")
	EndIf
	If !BondStarted
		StartBond(reason)
	EndIf
EndFunction

Function RefreshBladeOwnershipFromEquip()
	If IsBladeEquipped()
		MarkOwnedBlade("equip-scan")
	ElseIf HasTemplateBlade()
		MarkOwnedBlade("template-count")
	EndIf
EndFunction

String Function GetEquippedWeaponName()
	If !PlayerRef
		Return ""
	EndIf
	Weapon w = PlayerRef.GetEquippedWeapon(0)
	If !w
		Return ""
	EndIf
	Return w.GetName()
EndFunction

Bool Function PlayerHasBlade()
	If !PlayerRef
		Return False
	EndIf
	If OwnedPickmansBlade
		Return True
	EndIf
	If HasTemplateBlade()
		Return True
	EndIf
	If IsBladeEquipped()
		Return True
	EndIf
	Return False
EndFunction

Bool Function IsBladeEquipped()
	If !PlayerRef
		Return False
	EndIf
	ResolveVanillaForms()
	If PickmansBlade && PlayerRef.IsEquipped(PickmansBlade)
		Return True
	EndIf
	Weapon w = PlayerRef.GetEquippedWeapon(0)
	If IsPickmansBladeForm(w)
		OwnedPickmansBlade = True
		Return True
	EndIf
	Return False
EndFunction

Function StartBond(String reason)
	If BondStarted
		Return
	EndIf
	BondStarted = True
	Float now = Utility.GetCurrentGameTime()
	BondStartGameTime = now
	If LastKnifeActivityGameTime <= 0.0
		LastKnifeActivityGameTime = now
	EndIf
	LastHungerPollGameTime = now
	Debug.Trace("PickmansWhisper: bond started (" + reason + ")")
	If !IntroToastShown
		IntroToastShown = True
		String line = PickTrustLine()
		If line == ""
			line = "Something in the gallery leans closer... glad you came."
		EndIf
		ToastVoice(line)
	EndIf
	RefreshHungerPanel(False)
	RefreshDebugStatus()
EndFunction

; --- Trust voice ---------------------------------------------------------------

Function StartTrustVoice()
	CancelTimer(TIMER_TRUST)
	If !IsVoiceEnabled()
		Return
	EndIf
	StartTimer(TRUST_VOICE_SECONDS, TIMER_TRUST)
EndFunction

Function MaybeSpeakTrustLine()
	If !BondStarted || !IsVoiceEnabled()
		Return
	EndIf
	If Utility.IsInMenuMode()
		Return
	EndIf
	If !PlayerHasBlade() && !IsBladeEquipped() && !IsPlayerInGallery()
		Return
	EndIf
	Float now = Utility.GetCurrentRealTime()
	If (now - LastTrustToastRealTime) < TRUST_TOAST_COOLDOWN
		Return
	EndIf
	String line = PickTrustLine()
	If line != ""
		ToastVoice(line)
	EndIf
EndFunction

Function ToastVoice(String line)
	If line == "" || !IsVoiceEnabled()
		Return
	EndIf
	If Utility.IsInMenuMode()
		Return
	EndIf
	LastTrustToastRealTime = Utility.GetCurrentRealTime()
	Debug.Notification(line)
	Debug.Trace("PickmansWhisper: voice | " + line)
EndFunction

Function ToastHungerLine(String line)
	If line == "" || !IsVoiceEnabled()
		Return
	EndIf
	If Utility.IsInMenuMode()
		Return
	EndIf
	Float now = Utility.GetCurrentRealTime()
	If (now - LastHungerToastRealTime) < HUNGER_TOAST_COOLDOWN
		Return
	EndIf
	LastHungerToastRealTime = now
	Debug.Notification(line)
	Debug.Trace("PickmansWhisper: hunger voice | " + line)
EndFunction

; --- Line banks ----------------------------------------------------------------

Function LoadLineBanks()
	LoadTrustLines()
	LoadHungerLines()
EndFunction

Function LoadTrustLines()
	; Slice A: builtin banks only (no GoE hard dep). Config .txt ships for editing;
	; Slice C+ can reload from disk via Garden of Eden when that soft dep lands.
	UseBuiltinTrustFallback()
	Debug.Trace("PickmansWhisper: trust lines ready (" + TrustLineCount + ")")
EndFunction

Function LoadHungerLines()
	UseBuiltinHungerFallback()
	Debug.Trace("PickmansWhisper: hunger lines ready (" + HungerLineCount + ")")
EndFunction

Function UseBuiltinTrustFallback()
	TrustLines = new String[LINE_FILE_MAX]
	TrustLines[0] = "You hear me. Good. Stay a while."
	TrustLines[1] = "I like the way you hold still in these halls."
	TrustLines[2] = "We're getting along already... aren't we?"
	TrustLines[3] = "Keep the knife close. It likes you."
	TrustLines[4] = "No need to rush. I'm not going anywhere."
	TrustLines[5] = "The paint chips look like smiles up close."
	TrustLines[6] = "You came seeking a gift. You found a friend."
	TrustLines[7] = "Quiet steps. Careful hands. Perfect."
	TrustLineCount = 8
EndFunction

Function UseBuiltinHungerFallback()
	HungerLines = new String[LINE_FILE_MAX]
	HungerLines[0] = "A restless edge... the blade wants use."
	HungerLines[1] = "Hunger grows while the knife sleeps."
	HungerLines[2] = "You feel it — that neat, bright need."
	HungerLines[3] = "Feed me. Just once. You'll see."
	HungerLines[4] = "The itching behind your eyes is for someone soft and still."
	HungerLines[5] = "Unused steel turns mean. You know how to fix that."
	HungerLines[6] = "They won't understand. We will."
	HungerLineCount = 7
EndFunction

String Function PickTrustLine()
	If TrustLineCount <= 0 || !TrustLines
		LoadTrustLines()
	EndIf
	If TrustLineCount <= 0
		Return "You hear me. Good."
	EndIf
	Return TrustLines[Utility.RandomInt(0, TrustLineCount - 1)]
EndFunction

String Function PickHungerLine()
	If HungerLineCount <= 0 || !HungerLines
		LoadHungerLines()
	EndIf
	If HungerLineCount <= 0
		Return "The blade is hungry."
	EndIf
	Return HungerLines[Utility.RandomInt(0, HungerLineCount - 1)]
EndFunction

; --- Hunger --------------------------------------------------------------------

Function StartHungerPoll()
	EnsureHungerSpell()
	If LastHungerPollGameTime <= 0.0
		LastHungerPollGameTime = Utility.GetCurrentGameTime()
	EndIf
	CancelTimer(TIMER_HUNGER)
	StartTimer(HUNGER_POLL_SECONDS, TIMER_HUNGER)
	SyncHungerAddictionSpell()
	RefreshHungerPanel(False)
EndFunction

Function EnsureHungerSpell()
	If KnifeHungerSpell && KnifeHungerAgiEffect && KnifeHungerGlobal
		Return
	EndIf
	If !KnifeHungerSpell
		Form f = Game.GetFormFromFile(FID_HUNGER_SPEL, "PickmansWhisper.esp")
		KnifeHungerSpell = f as Spell
		If KnifeHungerSpell
			Debug.Trace("PickmansWhisper: Knife Hunger SPEL loaded")
		ElseIf !HungerSpellLoadWarned
			HungerSpellLoadWarned = True
			Debug.Trace("PickmansWhisper: ERROR Knife Hunger SPEL missing — rebuild ESP")
			Debug.Notification("Pickman's Whisper: Knife Hunger spell missing (update ESP)")
		EndIf
	EndIf
	If !KnifeHungerGlobal
		KnifeHungerGlobal = Game.GetFormFromFile(FID_HUNGER_GLOB, "PickmansWhisper.esp") as GlobalVariable
	EndIf
	If !KnifeHungerAgiEffect
		KnifeHungerAgiEffect = Game.GetFormFromFile(FID_HUNGER_MGEF_AGI, "PickmansWhisper.esp") as MagicEffect
	EndIf
	If !KnifeHungerChaEffect
		KnifeHungerChaEffect = Game.GetFormFromFile(FID_HUNGER_MGEF_CHA, "PickmansWhisper.esp") as MagicEffect
	EndIf
EndFunction

Bool Function IsHungerUnlocked()
	Return BondStarted
EndFunction

Bool Function IsHungerAddictionSpellEnabled()
	If MCM.IsInstalled()
		Return MCM.GetModSettingBool(MOD_NAME, "bAddictionSpell:Hunger")
	EndIf
	Return True
EndFunction

Bool Function IsVoiceEnabled()
	If MCM.IsInstalled()
		Return MCM.GetModSettingBool(MOD_NAME, "bVoiceToasts:Voice")
	EndIf
	Return True
EndFunction

Float Function GetHungerTimeGainPerHour()
	Float v = 5.0
	If MCM.IsInstalled()
		v = MCM.GetModSettingFloat(MOD_NAME, "fTimeGain:Hunger")
	EndIf
	If v < 0.0
		v = 0.0
	EndIf
	Return v
EndFunction

Float Function GetHungerAddictedThreshold()
	Float v = 70.0
	If MCM.IsInstalled()
		v = MCM.GetModSettingFloat(MOD_NAME, "fAddictedAt:Hunger")
	EndIf
	If v < 1.0
		v = 70.0
	EndIf
	Return v
EndFunction

Float Function GetHungerSatedHours()
	Float v = 2.0
	If MCM.IsInstalled()
		v = MCM.GetModSettingFloat(MOD_NAME, "fSatedHours:Hunger")
	EndIf
	If v < 0.5
		v = 0.5
	EndIf
	Return v
EndFunction

Bool Function IsHungerSated()
	Float now = Utility.GetCurrentGameTime()
	Return SatedUntilGameTime > 0.0 && now < SatedUntilGameTime
EndFunction

String Function GetHungerBandLabel(Float level)
	If level >= 90.0
		Return "desperate"
	ElseIf level >= 70.0
		Return "starving"
	ElseIf level >= 50.0
		Return "hungry"
	ElseIf level >= 25.0
		Return "restless"
	EndIf
	Return "calm"
EndFunction

Function RunHungerTick()
	If !IsHungerUnlocked()
		LastHungerPollGameTime = Utility.GetCurrentGameTime()
		HungerWasSated = False
		SyncHungerAddictionSpell()
		Return
	EndIf
	If Utility.IsInMenuMode()
		Return
	EndIf

	Float now = Utility.GetCurrentGameTime()
	If LastHungerPollGameTime <= 0.0
		LastHungerPollGameTime = now
	EndIf
	Float last = LastHungerPollGameTime

	Bool satedNow = IsHungerSated()
	If HungerWasSated && !satedNow
		ToastHungerLine("The quiet ends. The knife remembers.")
		ApplyHungerDelta(20.0, "withdrawal-onset")
	EndIf

	If !satedNow
		; Unused knife-time: blade owned (or bond active) without recent activity.
		; Slice A treats LastKnifeActivityGameTime as bond start until B updates it.
		Float gainStart = last
		If SatedUntilGameTime > gainStart
			If now > SatedUntilGameTime
				gainStart = SatedUntilGameTime
			Else
				gainStart = now
			EndIf
		EndIf
		Float hours = (now - gainStart) * 24.0
		If hours > 0.0
			ApplyHungerDelta(hours * GetHungerTimeGainPerHour(), "unused-knife-time")
		EndIf
	EndIf

	HungerWasSated = satedNow
	LastHungerPollGameTime = now
	SyncHungerAddictionSpell()
	RefreshHungerPanel(False)
EndFunction

Function ApplyHungerDelta(Float amount, String reason)
	If amount == 0.0
		Return
	EndIf
	Float before = HungerLevel
	HungerLevel = HungerLevel + amount
	If HungerLevel > 100.0
		HungerLevel = 100.0
	ElseIf HungerLevel < 0.0
		HungerLevel = 0.0
	EndIf
	Debug.Trace("PickmansWhisper: hunger " + before + " -> " + HungerLevel + " (" + reason + ")")
	MaybeToastHungerBand(before, HungerLevel)
	SyncHungerAddictionSpell()
EndFunction

Function MaybeToastHungerBand(Float before, Float after)
	Int band = 0
	If after >= 90.0
		band = 90
	ElseIf after >= 70.0
		band = 70
	ElseIf after >= 50.0
		band = 50
	ElseIf after >= 25.0
		band = 25
	EndIf
	If band > LastHungerBand
		LastHungerBand = band
		String line = PickHungerLine()
		If band == 25
			If line == ""
				line = "A restless edge... the blade wants use."
			EndIf
		ElseIf band == 50
			If line == ""
				line = "Hunger grows while the knife sleeps."
			EndIf
		ElseIf band == 70
			If line == ""
				line = "You feel it — that neat, bright need."
			EndIf
		ElseIf band == 90
			If line == ""
				line = "Feed me. Just once. You'll see."
			EndIf
		EndIf
		ToastHungerLine(line)
	ElseIf after < 25.0 && LastHungerBand > 0
		LastHungerBand = 0
	EndIf
EndFunction

; Slice B: call after a valid knife kill. Slice A exposes for MCM debug only.
Function SatiateHunger()
	Float now = Utility.GetCurrentGameTime()
	LastKnifeActivityGameTime = now
	LastHungerPollGameTime = now
	HungerLevel = 0.0
	LastHungerBand = 0
	SatedUntilGameTime = now + (GetHungerSatedHours() / 24.0)
	HungerWasSated = True
	BondIntensity = BondIntensity + 1.0
	SyncHungerAddictionSpell()
	RefreshHungerPanel(False)
	Debug.Trace("PickmansWhisper: hunger satiated until " + SatedUntilGameTime)
	ToastHungerLine("Yes... that was beautiful. Rest a moment.")
EndFunction

; Slice B entry: mark knife activity without full satiation (stub for kill tracking).
Function NoteKnifeActivity()
	LastKnifeActivityGameTime = Utility.GetCurrentGameTime()
	Debug.Trace("PickmansWhisper: knife activity noted (Slice B hook)")
EndFunction

String Function FormatSpecialSnapshot()
	If !PlayerRef
		Return "AGI=? CHA=?"
	EndIf
	ActorValue avAgi = Game.GetForm(0x000002C7) as ActorValue
	ActorValue avCha = Game.GetForm(0x000002C5) as ActorValue
	Float agi = -1.0
	Float cha = -1.0
	If avAgi
		agi = PlayerRef.GetValue(avAgi)
	EndIf
	If avCha
		cha = PlayerRef.GetValue(avCha)
	EndIf
	Return "AGI=" + (agi as Int) + " CHA=" + (cha as Int)
EndFunction

Function ApplyHungerStatPenalty()
	If !PlayerRef || HungerStatPenaltyApplied
		Return
	EndIf
	ActorValue avAgi = Game.GetForm(0x000002C7) as ActorValue
	ActorValue avCha = Game.GetForm(0x000002C5) as ActorValue
	If !avAgi
		avAgi = Game.GetFormFromFile(0x000002C7, "Fallout4.esm") as ActorValue
	EndIf
	If !avCha
		avCha = Game.GetFormFromFile(0x000002C5, "Fallout4.esm") as ActorValue
	EndIf
	If avAgi
		PlayerRef.ModValue(avAgi, -1.0)
	EndIf
	If avCha
		PlayerRef.ModValue(avCha, -1.0)
	EndIf
	HungerStatPenaltyApplied = True
	Debug.Trace("PickmansWhisper: SPECIAL -1 applied " + FormatSpecialSnapshot())
EndFunction

Function ClearHungerStatPenalty()
	If !PlayerRef || !HungerStatPenaltyApplied
		Return
	EndIf
	ActorValue avAgi = Game.GetForm(0x000002C7) as ActorValue
	ActorValue avCha = Game.GetForm(0x000002C5) as ActorValue
	If !avAgi
		avAgi = Game.GetFormFromFile(0x000002C7, "Fallout4.esm") as ActorValue
	EndIf
	If !avCha
		avCha = Game.GetFormFromFile(0x000002C5, "Fallout4.esm") as ActorValue
	EndIf
	If avAgi
		PlayerRef.ModValue(avAgi, 1.0)
	EndIf
	If avCha
		PlayerRef.ModValue(avCha, 1.0)
	EndIf
	HungerStatPenaltyApplied = False
	Debug.Trace("PickmansWhisper: SPECIAL +1 restored " + FormatSpecialSnapshot())
EndFunction

Bool Function ApplyHungerAddictionStandIn(Bool abAnnounce)
	If !PlayerRef
		Return False
	EndIf
	EnsureHungerSpell()
	If KnifeHungerSpell && PlayerRef.HasSpell(KnifeHungerSpell)
		PlayerRef.DispelSpell(KnifeHungerSpell)
		PlayerRef.RemoveSpell(KnifeHungerSpell)
	EndIf
	If KnifeHungerGlobal
		KnifeHungerGlobal.SetValue(0.0)
	EndIf
	If !HungerStatPenaltyApplied
		ApplyHungerStatPenalty()
	EndIf
	If HungerStatPenaltyApplied && abAnnounce
		Debug.Notification("Pickman's Whisper: knife hunger withdrawal AGI/CHA -1")
	EndIf
	Return HungerStatPenaltyApplied
EndFunction

Function ClearHungerAddictionStandIn()
	If !PlayerRef
		Return
	EndIf
	EnsureHungerSpell()
	If KnifeHungerSpell
		PlayerRef.DispelSpell(KnifeHungerSpell)
		If PlayerRef.HasSpell(KnifeHungerSpell)
			PlayerRef.RemoveSpell(KnifeHungerSpell)
		EndIf
	EndIf
	If KnifeHungerGlobal
		KnifeHungerGlobal.SetValue(0.0)
	EndIf
	ClearHungerStatPenalty()
EndFunction

Function SyncHungerAddictionSpell()
	EnsureHungerSpell()
	If !PlayerRef
		Return
	EndIf
	Bool want = IsHungerUnlocked() && IsHungerAddictionSpellEnabled() && HungerLevel >= GetHungerAddictedThreshold() && !IsHungerSated()
	If want
		If !HungerStatPenaltyApplied
			ApplyHungerAddictionStandIn(!HungerAddictionApplied)
		EndIf
		HungerAddictionApplied = HungerStatPenaltyApplied
	ElseIf HungerStatPenaltyApplied || HungerAddictionApplied
		ClearHungerAddictionStandIn()
		HungerAddictionApplied = False
		Debug.Trace("PickmansWhisper: hunger withdrawal cleared")
	EndIf
EndFunction

; --- MCM -----------------------------------------------------------------------

Function OnMCMMenuOpen(String modName)
	If modName != MOD_NAME
		Return
	EndIf
	RefreshHungerPanel(False)
	RefreshDebugStatus()
	If MCM.IsInstalled()
		MCM.RefreshMenu()
	EndIf
EndFunction

Function OnMCMSettingChange(String modName, String id)
	If modName != MOD_NAME
		Return
	EndIf
	If id == "bAddictionSpell:Hunger" || id == "fAddictedAt:Hunger"
		SyncHungerAddictionSpell()
		RefreshHungerPanel(True)
	ElseIf id == "bVoiceToasts:Voice"
		StartTrustVoice()
	EndIf
EndFunction

Function RefreshHungerPanel(Bool refreshMenu = True)
	If !MCM.IsInstalled()
		Return
	EndIf
	If !IsHungerUnlocked()
		MCM.SetModSettingString(MOD_NAME, "sHungerLevel:Hunger", "locked (visit gallery or take the blade)")
		MCM.SetModSettingString(MOD_NAME, "sHungerSated:Hunger", "—")
		MCM.SetModSettingString(MOD_NAME, "sBondState:Hunger", "not bonded")
	Else
		Int lvl = HungerLevel as Int
		String band = GetHungerBandLabel(HungerLevel)
		MCM.SetModSettingString(MOD_NAME, "sHungerLevel:Hunger", lvl + " / 100 (" + band + ")")
		If IsHungerSated()
			Float left = (SatedUntilGameTime - Utility.GetCurrentGameTime()) * 24.0
			If left < 0.0
				left = 0.0
			EndIf
			MCM.SetModSettingString(MOD_NAME, "sHungerSated:Hunger", "yes (" + (left as Int) + "h left)")
		Else
			MCM.SetModSettingString(MOD_NAME, "sHungerSated:Hunger", "no (sate with Pickman's Blade kills — Slice B)")
		EndIf
		MCM.SetModSettingString(MOD_NAME, "sBondState:Hunger", "bonded | intensity " + (BondIntensity as Int))
	EndIf
	If refreshMenu
		MCM.RefreshMenu()
	EndIf
EndFunction

Function ShowHungerInfo()
	RefreshHungerPanel(True)
	String msg = "Pickman's Whisper — Hunger\n\n"
	If !IsHungerUnlocked()
		msg += "Not bonded yet.\nEnter Pickman Gallery or obtain Pickman's Blade.\n"
		Debug.MessageBox(msg)
		Return
	EndIf
	msg += "Level: " + (HungerLevel as Int) + " / 100 (" + GetHungerBandLabel(HungerLevel) + ")\n"
	If IsHungerSated()
		Float left = (SatedUntilGameTime - Utility.GetCurrentGameTime()) * 24.0
		msg += "Sated: yes (" + (left as Int) + "h left)\n"
	Else
		msg += "Sated: no\n"
	EndIf
	msg += "Bond intensity: " + (BondIntensity as Int) + "\n"
	msg += "Addicted at: " + (GetHungerAddictedThreshold() as Int) + "\n"
	msg += "Withdrawal flag: " + HungerStatPenaltyApplied + "\n"
	msg += "SPECIAL now: " + FormatSpecialSnapshot() + "\n"
	msg += "\nRises with unused knife-time after bonding.\n"
	msg += "Slice B: killing with Pickman's Blade will sate hunger."
	Debug.MessageBox(msg)
EndFunction

Function ForceHungerAddictedTest()
	If !IsHungerUnlocked()
		Debug.MessageBox("Pickman's Whisper — Test\n\nBond first (gallery or blade).")
		Return
	EndIf
	If !IsHungerAddictionSpellEnabled()
		Debug.MessageBox("Pickman's Whisper — Test\n\nKnife Hunger effect is OFF in MCM.")
		Return
	EndIf
	If HungerStatPenaltyApplied
		ClearHungerAddictionStandIn()
	EndIf
	SatedUntilGameTime = 0.0
	HungerWasSated = False
	HungerLevel = 80.0
	LastHungerBand = 70
	HungerAddictionApplied = False
	String before = FormatSpecialSnapshot()
	SyncHungerAddictionSpell()
	RefreshHungerPanel(True)
	String msg = "Hunger forced to 80.\nBefore: " + before + "\nAfter: " + FormatSpecialSnapshot() + "\n"
	msg += "Withdrawal flag: " + HungerStatPenaltyApplied
	Debug.MessageBox("Pickman's Whisper — Test\n\n" + msg)
EndFunction

Function DebugForceBond()
	StartBond("mcm-debug")
	RefreshDebugStatus()
	Debug.MessageBox("Pickman's Whisper\n\nBond forced. Hunger unlocked.")
EndFunction

Function DebugSatiateHunger()
	If !IsHungerUnlocked()
		Debug.MessageBox("Pickman's Whisper\n\nBond first.")
		Return
	EndIf
	SatiateHunger()
	RefreshHungerPanel(True)
	Debug.MessageBox("Pickman's Whisper\n\nHunger satiated (debug stand-in for Slice B knife kill).")
EndFunction

Function DebugReloadLines()
	LoadLineBanks()
	Debug.MessageBox("Pickman's Whisper\n\nReloaded line banks.\nTrust: " + TrustLineCount + "\nHunger: " + HungerLineCount)
EndFunction

Function DebugTestTrustLine()
	String line = PickTrustLine()
	ToastVoice(line)
	If Utility.IsInMenuMode()
		Debug.MessageBox("Pickman's Whisper\n\n" + line)
	EndIf
EndFunction

Function RefreshDebugStatus()
	If !MCM.IsInstalled()
		Return
	EndIf
	Bool allOk = True
	Int f4seRel = F4SE.GetVersionRelease()
	If f4seRel > 0
		MCM.SetModSettingString(MOD_NAME, "sF4SE:Debug", "OK (release " + f4seRel + ")")
	Else
		MCM.SetModSettingString(MOD_NAME, "sF4SE:Debug", "MISSING")
		allOk = False
	EndIf
	If MCM.IsInstalled()
		MCM.SetModSettingString(MOD_NAME, "sMCM:Debug", "OK")
	Else
		MCM.SetModSettingString(MOD_NAME, "sMCM:Debug", "MISSING")
		allOk = False
	EndIf
	ResolveVanillaForms()
	RefreshBladeOwnershipFromEquip()
	If PickmansBlade
		MCM.SetModSettingString(MOD_NAME, "sBlade:Debug", "OK template loaded")
	Else
		MCM.SetModSettingString(MOD_NAME, "sBlade:Debug", "MISSING template")
		allOk = False
	EndIf
	String eqName = GetEquippedWeaponName()
	If eqName == ""
		eqName = "(none)"
	EndIf
	If PlayerHasBlade()
		String how = ""
		If OwnedPickmansBlade
			how = "owned(name)"
		EndIf
		If HasTemplateBlade()
			If how != ""
				how = how + "+"
			EndIf
			how = how + "template"
		EndIf
		If how == ""
			how = "yes"
		EndIf
		MCM.SetModSettingString(MOD_NAME, "sBladeInv:Debug", how)
	Else
		MCM.SetModSettingString(MOD_NAME, "sBladeInv:Debug", "not owned | eq=" + eqName)
	EndIf
	If IsBladeEquipped()
		MCM.SetModSettingString(MOD_NAME, "sBladeEq:Debug", "equipped | " + eqName)
	Else
		MCM.SetModSettingString(MOD_NAME, "sBladeEq:Debug", "not equipped | " + eqName)
	EndIf
	If IsPlayerInGallery()
		MCM.SetModSettingString(MOD_NAME, "sCell:Debug", "Pickman Gallery")
	ElseIf PlayerRef && PlayerRef.GetParentCell()
		MCM.SetModSettingString(MOD_NAME, "sCell:Debug", "other cell")
	Else
		MCM.SetModSettingString(MOD_NAME, "sCell:Debug", "unknown")
	EndIf
	If BondStarted
		MCM.SetModSettingString(MOD_NAME, "sBond:Debug", "bonded")
	Else
		MCM.SetModSettingString(MOD_NAME, "sBond:Debug", "not bonded")
	EndIf
	EnsureHungerSpell()
	If KnifeHungerSpell
		MCM.SetModSettingString(MOD_NAME, "sHungerSpell:Debug", "OK")
	Else
		MCM.SetModSettingString(MOD_NAME, "sHungerSpell:Debug", "MISSING SPEL")
		allOk = False
	EndIf
	If allOk
		MCM.SetModSettingString(MOD_NAME, "sOverall:Debug", "OK")
	Else
		MCM.SetModSettingString(MOD_NAME, "sOverall:Debug", "Issues — see rows")
	EndIf
EndFunction
